# Loading libraries

library(tidyverse)
library(keras)

# Function to plot images
plot_image <- function(images, labels, i) {
  img <- images[i, , ]
  img <- t(apply(img, 2, rev))
  image(1:28, 1:28, img, col = gray((0:255)/255), xlab = "", ylab = "",
        main = paste(class_names[labels[i] + 1]))
}

# Load fashion MNIST dataset
fashion_mnist <- dataset_fashion_mnist()
train_images <- fashion_mnist$train$x
train_labels <- fashion_mnist$train$y
test_images <- fashion_mnist$test$x
test_labels <- fashion_mnist$test$y

# Display shape of train_images
shape_train_images <- dim(train_images)
print(shape_train_images)

# Reshape train and test images
x_train <- train_images / 255
x_test <- test_images / 255
x_train <- array_reshape(x_train, c(nrow(x_train), 28, 28, 1))
x_test <- array_reshape(x_test, c(nrow(x_test), 28, 28, 1))

# Define class names
class_names <- c('T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat', 
                 'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot')

# Plot some sample images
options(repr.plot.width=5, repr.plot.height=5) 
par(mfcol=c(5,5))
par(mar=c(0, 0, 1.5, 0), xaxs='i', yaxs='i')
for (i in 1:25) { 
  img <- train_images[i, , ]
  img <- t(apply(img, 2, rev)) 
  image(1:28, 1:28, img, col = gray((0:255)/255), xaxt = 'n', yaxt = 'n',
        main = paste(class_names[train_labels[i] + 1]))
}

# Define the CNN model
model <- keras_model_sequential()
model %>%
  layer_flatten(input_shape = c(28, 28)) %>%
  layer_dense(units = 128, activation = 'relu') %>%
  layer_dense(units = 10, activation = 'softmax')

# Compile the model
model %>% compile(
  loss = 'sparse_categorical_crossentropy',
  optimizer = 'adam', 
  metrics = c('accuracy')
)

# Display model summary
summary(model)

# Evaluate test accuracy
result <- evaluate(model, test_images, test_labels)
test_loss <- result$loss
test_acc <- result$accuracy

cat("Test accuracy:", test_acc, "\n")